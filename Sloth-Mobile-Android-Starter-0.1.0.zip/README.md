# Sloth Mobile — Android starter 0.1.0

Esta carpeta añade una primera app Android nativa al repositorio Sloth. No reemplaza ni modifica el Sloth original.

## Qué incluye ahora
- Aplicación Android nativa (Kotlin), sin Electron.
- Campo para guardar la URL HTTPS del servidor.
- Prueba básica de `GET /api/state`.
- Selector de carpetas de Android (Storage Access Framework) y permiso persistente solo para la carpeta elegida.
- GitHub Actions para compilar un APK de depuración y publicarlo como artefacto.

## Lo que todavía NO hace
- No inicia sesiones de agentes ni envía mensajes.
- No incluye un servidor remoto seguro ni autenticación.
- No sube archivos de la carpeta elegida.
- No es todavía el Sloth completo ni un APK de producción.

## Cómo incorporarlo a tu repositorio
Copia el contenido de esta carpeta a la raíz de tu repositorio `ElMacho17/Hstm`, conservando las rutas. La carpeta `android/` debe quedar en la raíz, junto a `.github/` y `README.md`.

Después, en GitHub:
1. Abre la pestaña **Actions**.
2. Selecciona **Build Sloth Mobile APK**.
3. Pulsa **Run workflow**.
4. Cuando termine, abre la ejecución y descarga el artefacto **Sloth-Mobile-debug**.

## Requisitos
- Android 8.0 o superior (API 26+).
- La prueba de servidor requiere una URL HTTPS. El servidor original de Sloth escucha en localhost y no debe exponerse directamente a Internet; antes de conectar agentes hace falta una puerta de enlace autenticada y aislada.

## Nota de seguridad
No publiques claves de proveedores, contraseñas, tokens ni credenciales en el repositorio o dentro del APK.
