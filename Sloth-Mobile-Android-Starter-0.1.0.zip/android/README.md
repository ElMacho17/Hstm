Proyecto Android nativo de Sloth Mobile. Compilación: `gradle :app:assembleDebug` desde esta carpeta.
