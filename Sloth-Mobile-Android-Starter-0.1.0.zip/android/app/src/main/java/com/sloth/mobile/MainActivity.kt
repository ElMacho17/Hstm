package com.sloth.mobile

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var folderInfo: TextView
    private lateinit var serverInput: EditText
    private val prefs by lazy { getSharedPreferences("sloth_mobile", MODE_PRIVATE) }
    private val chooseFolder = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 22, 32)
        window.navigationBarColor = Color.rgb(18, 22, 32)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(14, 18, 27))
        }
        fun text(value: String, size: Float, color: Int = Color.WHITE): TextView =
            TextView(this).apply { text = value; textSize = size; setTextColor(color) }
        fun button(value: String, action: () -> Unit) = Button(this).apply {
            text = value; isAllCaps = false; setOnClickListener { action() }
        }
        page.addView(text("SLOTH MOBILE", 25f))
        page.addView(text("Tu espacio de trabajo, desde Android.", 14f, Color.LTGRAY))
        page.addView(space(22))
        page.addView(text("Conexión al servidor", 18f))
        serverInput = EditText(this).apply {
            setSingleLine(true)
            hint = "https://tu-servidor.example"
            setText(prefs.getString("server_url", ""))
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(14, 8, 14, 8)
        }
        page.addView(serverInput)
        page.addView(button("Guardar dirección") {
            prefs.edit().putString("server_url", serverInput.text.toString().trim().trimEnd('/')).apply()
            showStatus("Dirección guardada en este teléfono.")
        })
        page.addView(button("Probar conexión") { checkServer() })
        status = text("Estado: sin comprobar", 14f, Color.rgb(190, 205, 220))
        page.addView(status)
        page.addView(space(18))
        page.addView(text("Carpeta de trabajo", 18f))
        folderInfo = text(
            prefs.getString("folder_label", "Todavía no has elegido una carpeta.") ?: "Todavía no has elegido una carpeta.",
            14f, Color.LTGRAY
        )
        page.addView(folderInfo)
        page.addView(button("Elegir carpeta autorizada") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            startActivityForResult(intent, chooseFolder)
        })
        page.addView(space(18))
        page.addView(text("Tu privacidad", 18f))
        page.addView(text(
            "Sloth Mobile solo recibe acceso a la carpeta que selecciones. Esta versión inicial no escanea el teléfono ni envía tus archivos al servidor automáticamente.",
            14f, Color.LTGRAY
        ))
        page.addView(space(18))
        page.addView(text("Versión 0.1.0 · Base Android", 12f, Color.GRAY))
        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun space(dp: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp * resources.displayMetrics.density.toInt().coerceAtLeast(1))
    }

    private fun showStatus(message: String) {
        runOnUiThread { status.text = "Estado: $message" }
    }

    private fun checkServer() {
        val base = serverInput.text.toString().trim().trimEnd('/')
        if (!base.startsWith("https://")) {
            showStatus("usa una dirección HTTPS válida.")
            return
        }
        prefs.edit().putString("server_url", base).apply()
        showStatus("comprobando…")
        thread {
            var connection: HttpURLConnection? = null
            try {
                connection = URL("$base/api/state").openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 8000
                connection.readTimeout = 8000
                val code = connection.responseCode
                showStatus(if (code in 200..299) "servidor responde (HTTP $code)." else "servidor respondió HTTP $code; falta validar compatibilidad.")
            } catch (_: Exception) {
                showStatus("no se pudo conectar. Revisa la dirección y que el servidor esté activo.")
            } finally { connection?.disconnect() }
        }
    }

    @Deprecated("Legacy Android picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == chooseFolder && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) {}
            prefs.edit().putString("folder_uri", uri.toString())
                .putString("folder_label", uri.lastPathSegment ?: "Carpeta autorizada").apply()
            folderInfo.text = "Carpeta autorizada: ${uri.lastPathSegment ?: "seleccionada"}"
        }
    }
}
