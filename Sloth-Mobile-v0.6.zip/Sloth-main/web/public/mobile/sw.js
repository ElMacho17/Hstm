const CACHE='sloth-mobile-v4';
const CORE=['/mobile/','/mobile/index.html','/mobile/styles.css','/mobile/app.js','/mobile/manifest.webmanifest','/mobile/icons/icon-192.png','/mobile/icons/icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(u.origin!==location.origin||u.pathname.startsWith('/api/')||u.pathname==='/ws')return;if(e.request.method!=='GET')return;e.respondWith(fetch(e.request).then(r=>{if(r.ok&&u.pathname.startsWith('/mobile/')){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));}return r;}).catch(()=>caches.match(e.request).then(r=>r||caches.match('/mobile/'))));});
