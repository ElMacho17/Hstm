(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = { cards: [], sessions: [], models: [], sessionId: null, events: [], socket: null, files: [], busy: false, reconnect: 0, folderUri: null, currentFolderUri: null, editingUri: null, editingName: '' };
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let toastTimer;
  function toast(message) { const el=$('toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),2800); }
  async function api(path, options={}) {
    const res = await fetch(path, { ...options, headers: { ...(options.body instanceof Blob ? {} : {'content-type':'application/json'}), ...(options.headers||{}) } });
    const raw = await res.text(); let data={}; try { data=raw?JSON.parse(raw):{}; } catch { data={error:raw}; }
    if (!res.ok) throw new Error(data.error || `Error ${res.status}`);
    return data;
  }
  function setConnection(ok) { $('connection').classList.toggle('online',ok); $('connection').innerHTML = `<i></i> ${ok?'Conectado':'Sin conexión'}`; }
  function modelOptions() {
    const select=$('model-select'); const previous=select.value;
    select.innerHTML='';
    if (!state.models.length) { select.add(new Option('Conecta un agente en Sloth','')); select.disabled=true; return; }
    select.disabled=false;
    state.models.forEach(m=>select.add(new Option(m.label || m.id,m.id)));
    select.value=state.models.some(m=>m.id===previous)?previous:state.models[0].id;
    updateEfforts();
  }
  function updateEfforts() {
    const m=state.models.find(x=>x.id===$('model-select').value); const s=$('effort-select'); const previous=s.value;
    s.innerHTML=''; s.add(new Option('Auto',''));
    (m?.efforts||[]).forEach(e=>s.add(new Option(({low:'Bajo',medium:'Medio',high:'Alto',max:'Máximo'}[e]||e),e)));
    s.disabled=!(m?.efforts||[]).length; if ((m?.efforts||[]).includes(previous)) s.value=previous; else if(m?.defaultEffort) s.value=m.defaultEffort;
  }
  function renderSessions() {
    const root=$('sessions'); root.innerHTML='';
    const items=state.sessions.filter(s=>!s.archived).sort((a,b)=>(b.updatedAt||b.createdAt||0)-(a.updatedAt||a.createdAt||0));
    if(!items.length){root.innerHTML='<div class="muted side-empty">Tus trabajos aparecerán aquí.</div>';return;}
    items.forEach(s=>{const b=document.createElement('button');b.className='session-item'+(s.id===state.sessionId?' active':'');b.textContent=s.title||'Trabajo sin título';b.title=b.textContent;b.onclick=()=>openSession(s.id);root.appendChild(b);});
  }
  function setBusy(busy) { state.busy=busy; $('send-button').disabled=busy; $('stop-button').classList.toggle('hidden',!busy); }
  function eventText(e) {
    if(e.t==='user') return {kind:'user',text:e.text||''};
    if(e.t==='text') return {kind:'assistant',text:e.delta||''};
    if(e.t==='thinking') return {kind:'tool',text:e.delta||'Pensando…'};
    if(e.t==='info') return {kind:'tool',text:e.text||''};
    if(e.t==='arranque') return {kind:'tool',text:e.listo?'Agente iniciado':`Preparando ${e.nombre||'agente'}…`};
    if(e.t==='background') return {kind:'tool',text:(e.tasks||[]).length?`Tareas en segundo plano: ${(e.tasks||[]).join(', ')}`:'Sin tareas en segundo plano'};
    if(e.t==='tool') return {kind:'tool',text:`Usando ${e.name||'herramienta'}`};
    if(e.t==='tool_update') return {kind:'tool',text:e.error?'La herramienta informó un error.':(e.output||e.delta||'Herramienta ejecutada')};
    if(e.t==='turn_start') return {kind:'tool',text:'El agente está trabajando…'};
    if(e.t==='turn_end') return {kind:'tool',text:e.ok?'Turno terminado':`El turno terminó con un problema${e.error?': '+e.error:''}`};
    if(e.t==='error') return {kind:'tool',text:e.message||e.error||'Ocurrió un error'};
    return null;
  }
  function renderMessages() {
    const root=$('messages');root.innerHTML='';
    let last=null;
    for(const e of state.events){const v=eventText(e);if(!v)continue;
      if(v.kind==='assistant' && last?.className==='message assistant') {last.textContent+=v.text;continue;}
      const el=document.createElement('div');el.className='message '+v.kind;
      if(v.kind==='assistant'){const label=document.createElement('div');label.className='message-label';label.textContent='SLOTH';el.appendChild(label);const body=document.createElement('div');body.textContent=v.text;el.appendChild(body);}
      else el.textContent=v.text;
      root.appendChild(el);last=el;
    }
    root.scrollTop=root.scrollHeight;
  }
  async function refreshSession(id=state.sessionId) {
    if(!id)return;
    try { const h=await api(`/api/sessions/${encodeURIComponent(id)}/historial`); if(id!==state.sessionId)return; state.events=h.events||[]; renderMessages(); }
    catch(e){toast(e.message);}
    const meta=state.sessions.find(s=>s.id===id);
    if(meta) setBusy(!!meta.running);
  }
  async function openSession(id) {
    state.sessionId=id; $('welcome').classList.add('hidden'); $('conversation').classList.remove('hidden');
    const s=state.sessions.find(x=>x.id===id); $('chat-title').textContent=s?.title||'Trabajo'; renderSessions();
    if(state.socket?.readyState===WebSocket.OPEN) state.socket.send(JSON.stringify({type:'subscribe',sessionId:id}));
    await refreshSession(id); $('sidebar').classList.remove('open');
  }
  function newChat(prefill='') {
    state.sessionId=null;state.events=[];renderMessages();$('welcome').classList.remove('hidden');$('conversation').classList.add('hidden');$('prompt').value=prefill;$('prompt').focus();renderSessions();$('sidebar').classList.remove('open');
    if(state.socket?.readyState===WebSocket.OPEN)state.socket.send(JSON.stringify({type:'subscribe',sessionId:null}));
  }
  async function loadState() {
    const d=await api('/api/state');state.cards=d.cards||[];state.sessions=d.sessions||[];state.models=d.models||[];modelOptions();renderSessions();
    if(state.sessionId && state.sessions.some(s=>s.id===state.sessionId)) await refreshSession();
    else if(!state.sessionId && state.sessions.length) { /* no abrir un hilo sin que el usuario lo elija */ }
    if(!state.models.length)toast('Conecta Claude, Codex u OpenCode en Sloth para usar el agente.');
  }
  async function uploadFiles(files) {
    const uploaded=[];
    for(const file of files){
      const res=await fetch(`/api/upload?name=${encodeURIComponent(file.name)}`,{method:'POST',body:file});
      const d=await res.json();if(!res.ok)throw new Error(d.error||`No se pudo subir ${file.name}`);
      uploaded.push({name:file.name,path:d.path});
    }
    return uploaded;
  }
  async function sendMessage() {
    const text=$('prompt').value.trim(); if(!text && !state.files.length)return;
    if(!state.models.length){toast('Primero conecta un modelo en Sloth.');return;}
    $('send-button').disabled=true;
    try {
      const attachments=state.files.length?await uploadFiles(state.files):[];
      const fullText=[text,attachments.length?'Archivos adjuntos disponibles en estas rutas locales:\n'+attachments.map(a=>`- ${a.name}: ${a.path}`).join('\n'):''].filter(Boolean).join('\n\n');
      if(state.sessionId){await api(`/api/sessions/${encodeURIComponent(state.sessionId)}/send`,{method:'POST',body:JSON.stringify({text:fullText})});}
      else {
        const card=state.cards.find(c=>c.id==='agente-general')||state.cards[0];if(!card)throw new Error('No hay una card disponible.');
        const meta=await api('/api/sessions',{method:'POST',body:JSON.stringify({cardId:card.id,model:$('model-select').value,effort:$('effort-select').value||undefined,text:fullText})});
        state.sessionId=meta.id;await loadState();await openSession(meta.id);
      }
      $('prompt').value='';$('prompt').style.height='auto';state.files=[];$('file-input').value='';$('attachment-label').textContent='';
      if(state.socket?.readyState===WebSocket.OPEN)state.socket.send(JSON.stringify({type:'subscribe',sessionId:state.sessionId}));
      await loadState();await refreshSession(state.sessionId);
    } catch(e){toast(e.message||'No se pudo enviar el mensaje.');}
    finally{$('send-button').disabled=false;}
  }
  async function stopSession(){if(!state.sessionId)return;try{await api(`/api/sessions/${encodeURIComponent(state.sessionId)}/stop`,{method:'POST',body:'{}'});toast('Se pidió detener el trabajo.');}catch(e){toast(e.message);}}
  function connectSocket(){
    const proto=location.protocol==='https:'?'wss:':'ws:';const ws=new WebSocket(`${proto}//${location.host}/ws`);state.socket=ws;
    ws.onopen=()=>{state.reconnect=0;setConnection(true);ws.send(JSON.stringify({type:'subscribe',sessionId:state.sessionId}));};
    ws.onmessage=(ev)=>{let m;try{m=JSON.parse(ev.data)}catch{return}
      if(m.type==='models'){state.models=m.models||[];modelOptions();}
      if(m.type==='cards'){state.cards=m.cards||[];}
      if(m.type==='session'){const i=state.sessions.findIndex(s=>s.id===m.session.id);if(i>=0)state.sessions[i]=m.session;else state.sessions.unshift(m.session);renderSessions();if(m.session.id===state.sessionId){$('chat-title').textContent=m.session.title||'Trabajo';setBusy(!!m.session.running);}}
      if(m.type==='removed'){state.sessions=state.sessions.filter(s=>s.id!==m.sessionId);renderSessions();}
      if((m.type==='events'||m.type==='draft')&&m.sessionId===state.sessionId)refreshSession(state.sessionId);
    };
    ws.onclose=()=>{setConnection(false);const wait=Math.min(10000,1000*Math.pow(1.5,state.reconnect++));setTimeout(connectSocket,wait);};ws.onerror=()=>ws.close();
  }

  function initNativeFiles(){
    if(!window.SlothAndroid)return;
    document.querySelectorAll('.native-only').forEach(el=>el.style.display='inline-flex');
    const saved=window.SlothAndroid.getGrantedFolder();
    if(saved){state.folderUri=saved;state.currentFolderUri=saved;$('folder-status').textContent='Carpeta autorizada. Sloth solo puede acceder a esta ubicación.';$('folder-refresh').disabled=false;$('folder-new').disabled=false;}
    $('folder-button').addEventListener('click',()=>{$('folder-panel').classList.remove('hidden');if(state.folderUri)loadFolder(state.currentFolderUri||state.folderUri);});
    $('folder-close').addEventListener('click',()=>$('folder-panel').classList.add('hidden'));
    $('folder-choose').addEventListener('click',()=>window.SlothAndroid.chooseFolder());
    $('folder-refresh').addEventListener('click',()=>loadFolder(state.currentFolderUri||state.folderUri));
    $('folder-new').addEventListener('click',()=>{if(!state.currentFolderUri)return;const name=prompt('Nombre del archivo nuevo');if(!name)return;const result=window.SlothAndroid.createText(state.currentFolderUri,name,'');if(result.startsWith('__SLOTH_ERROR__'))toast(result.replace('__SLOTH_ERROR__',''));else{toast('Archivo creado');loadFolder(state.currentFolderUri);}});
    $('editor-save').addEventListener('click',()=>{if(!state.editingUri)return;const result=window.SlothAndroid.writeText(state.editingUri,$('editor-content').value);if(result==='ok')toast('Cambios guardados en el teléfono');else toast(result.replace('error:','No se pudo guardar: '));});
    $('editor-cancel').addEventListener('click',()=>$('file-editor').classList.add('hidden'));
  }
  function loadFolder(uri){
    if(!window.SlothAndroid||!uri)return;
    try{const raw=window.SlothAndroid.list(uri);const data=JSON.parse(raw);if(data.error)throw new Error(data.error);state.currentFolderUri=uri;$('folder-list').innerHTML='';
      data.sort((a,b)=>{const ad=a.mime==='vnd.android.document/directory',bd=b.mime==='vnd.android.document/directory';return ad===bd?a.name.localeCompare(b.name):ad?-1:1;});
      if(uri!==state.folderUri){const up=document.createElement('div');up.className='folder-entry';const back=document.createElement('button');back.className='folder-open';back.textContent='⬅ Volver a la carpeta anterior';back.onclick=()=>{const parent=window.SlothAndroid.parent(uri);if(parent)loadFolder(parent);};up.appendChild(back);$('folder-list').appendChild(up);}
      data.forEach(item=>{const row=document.createElement('div');row.className='folder-entry';const open=document.createElement('button');open.className='folder-open';open.textContent=(item.mime==='vnd.android.document/directory'?'📁 ':'📄 ')+item.name;open.onclick=()=>{if(item.mime==='vnd.android.document/directory')loadFolder(item.uri);else editPhoneFile(item);};row.appendChild(open);
        if(item.mime==='vnd.android.document/directory'){const count=document.createElement('small');count.textContent='Carpeta';row.appendChild(count);}else{const importBtn=document.createElement('button');importBtn.className='folder-import';importBtn.textContent='Adjuntar';importBtn.onclick=()=>importPhoneFile(item);row.appendChild(importBtn);} $('folder-list').appendChild(row);});
      if(!data.length)$('folder-list').textContent='Esta carpeta está vacía.';
      $('folder-status').textContent='Acceso concedido por ti. Puedes abrir y editar archivos de texto o adjuntarlos al agente.';$('folder-new').disabled=false;$('folder-refresh').disabled=false;
    }catch(e){toast('No se pudo leer la carpeta: '+e.message);}
  }
  function isTextFile(item){return (item.mime||'').startsWith('text/') || /\.(txt|md|json|js|mjs|ts|tsx|jsx|html|css|xml|yml|yaml|py|java|kt|c|cpp|h|sh|toml|ini|csv|sql|gradle)$/i.test(item.name||'');}
  function editPhoneFile(item){
    if(!isTextFile(item)){toast('Este archivo no es texto. Puedes adjuntarlo al agente.');return;}
    const content=window.SlothAndroid.readText(item.uri);if(content.startsWith('__SLOTH_ERROR__')){toast(content.replace('__SLOTH_ERROR__',''));return;}
    state.editingUri=item.uri;state.editingName=item.name;$('editor-name').textContent=item.name;$('editor-content').value=content;$('file-editor').classList.remove('hidden');
  }
  function importPhoneFile(item){
    let file;
    if(isTextFile(item)){const content=window.SlothAndroid.readText(item.uri);if(content.startsWith('__SLOTH_ERROR__')){toast(content.replace('__SLOTH_ERROR__',''));return;}file=new File([content],item.name,{type:item.mime||'text/plain'});}
    else {const encoded=window.SlothAndroid.readBase64(item.uri);if(encoded.startsWith('__SLOTH_ERROR__')){toast(encoded.replace('__SLOTH_ERROR__',''));return;}const raw=atob(encoded),bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);file=new File([bytes],item.name,{type:item.mime||'application/octet-stream'});}
    state.files.push(file);$('attachment-label').textContent=state.files.map(f=>f.name).join(', ');$('folder-panel').classList.add('hidden');toast('Archivo añadido a los adjuntos');
  }
  window.slothFolderSelected=(uri)=>{state.folderUri=uri;state.currentFolderUri=uri;$('folder-panel').classList.remove('hidden');loadFolder(uri);};
  window.slothFolderError=(message)=>toast(message||'No se pudo autorizar la carpeta');

  $('send-button').addEventListener('click',sendMessage);$('stop-button').addEventListener('click',stopSession);$('new-chat').addEventListener('click',()=>newChat());$('menu-toggle').addEventListener('click',()=>$('sidebar').classList.toggle('open'));
  $('model-select').addEventListener('change',updateEfforts);
  $('prompt').addEventListener('input',e=>{e.target.style.height='auto';e.target.style.height=Math.min(e.target.scrollHeight,180)+'px';});
  $('prompt').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage();}});
  $('file-input').addEventListener('change',e=>{state.files=Array.from(e.target.files||[]);$('attachment-label').textContent=state.files.map(f=>f.name).join(', ');});
  document.querySelectorAll('.quick').forEach(b=>b.addEventListener('click',()=>newChat(b.dataset.prompt||'')));
  initNativeFiles();
  if('serviceWorker' in navigator)navigator.serviceWorker.register('/mobile/sw.js').catch(()=>{});
  loadState().catch(e=>{setConnection(false);toast(e.message);});connectSocket();
  setInterval(()=>{if(!state.socket||state.socket.readyState!==WebSocket.OPEN)loadState().catch(()=>{});},6000);
})();
