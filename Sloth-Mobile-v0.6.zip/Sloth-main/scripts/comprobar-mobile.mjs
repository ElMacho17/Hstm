import { readFileSync, existsSync, statSync } from 'node:fs'
import { join } from 'node:path'

const root = process.cwd()
const read = (p) => readFileSync(join(root, p), 'utf8')
const fail = (m) => { console.error(`✗ ${m}`); process.exitCode = 1 }
const ok = (m) => console.log(`✓ ${m}`)

try {
  const cards = JSON.parse(read('cards.json'))
  const card = cards.find(c => c.id === 'agente-general')
  if (!card || card.skill !== 'agente-general' || card.cwd) fail('La card agente-general debe existir, usar la skill correspondiente y dejar cwd sin definir.')
  else ok('Card agente-general y carpeta de trabajo privada por card')
  if (!existsSync(join(root, 'skills/agente-general/SKILL.md'))) fail('Falta skills/agente-general/SKILL.md')
  else ok('Skill del agente general')
  const manifest = JSON.parse(read('web/public/mobile/manifest.webmanifest'))
  if (manifest.start_url !== '/mobile/' || manifest.scope !== '/mobile/') fail('El manifest debe limitar start_url y scope a /mobile/.')
  else ok('Manifest PWA válido')
  for (const p of ['web/public/mobile/index.html','web/public/mobile/styles.css','web/public/mobile/app.js','web/public/mobile/sw.js','web/public/mobile/icons/icon-192.png','web/public/mobile/icons/icon-512.png']) {
    if (!existsSync(join(root,p)) || statSync(join(root,p)).size === 0) fail(`Falta o está vacío: ${p}`)
  }
  if (!process.exitCode) ok('Archivos PWA e iconos')
  const js = read('web/public/mobile/app.js')
  for (const route of ['/api/state','/api/sessions','/historial','/send','/stop','/api/upload','/ws']) if (!js.includes(route)) fail(`Falta ruta esperada en app.js: ${route}`)
  if (!process.exitCode) ok('Rutas de API reales referenciadas')
  const nativeFiles = ['android/settings.gradle','android/build.gradle','android/app/build.gradle','android/app/src/main/AndroidManifest.xml','android/app/src/main/java/com/sloth/mobile/MainActivity.java','android/app/src/main/res/xml/network_security_config.xml','docs/ANDROID-NATIVO.md']
  for (const p of nativeFiles) if (!existsSync(join(root,p)) || statSync(join(root,p)).size === 0) fail(`Falta componente Android: ${p}`)
  const native = read('android/app/src/main/java/com/sloth/mobile/MainActivity.java')
  for (const marker of ['ACTION_OPEN_DOCUMENT_TREE','takePersistableUriPermission','checkedDocument','readBase64','@JavascriptInterface','127.0.0.1:4848']) if (!native.includes(marker)) fail(`Falta capacidad/seguridad Android: ${marker}`)
  const manifestXml = read('android/app/src/main/AndroidManifest.xml')
  if (manifestXml.includes('MANAGE_EXTERNAL_STORAGE') || manifestXml.includes('READ_EXTERNAL_STORAGE') || manifestXml.includes('WRITE_EXTERNAL_STORAGE')) fail('No se deben solicitar permisos generales de almacenamiento.')
  else if (!process.exitCode) ok('Shell Android y SAF presentes; sin permisos generales de almacenamiento')
} catch (e) { fail(e.message) }
if (process.exitCode) process.exit(process.exitCode)
console.log('Sloth Mobile: comprobación estática terminada.')
