package com.sloth.mobile;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.content.ActivityNotFoundException;
import android.provider.DocumentsContract;
import android.database.Cursor;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.util.Base64;

public class MainActivity extends Activity {
    private static final int PICK_TREE = 7101;
    private WebView web;
    private Uri grantedTree;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(0);
        String savedTree = getPreferences(MODE_PRIVATE).getString("authorized_tree_uri", null);
        if (savedTree != null) {
            Uri candidate = Uri.parse(savedTree);
            for (android.content.UriPermission permission : getContentResolver().getPersistedUriPermissions()) {
                if (permission.getUri().equals(candidate) && permission.isReadPermission() && permission.isWritePermission()) { grantedTree = candidate; break; }
            }
        }
        web = new WebView(this);
        web.setBackgroundColor(0xFF171512);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setSafeBrowsingEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri target = request.getUrl();
                if (isTrustedLocal(target)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, target)); } catch (ActivityNotFoundException ignored) {}
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri target = request.getUrl();
                if (!isTrustedLocal(target))
                    return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", null, new java.io.ByteArrayInputStream(new byte[0]));
                return super.shouldInterceptRequest(view, request);
            }
            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) view.loadDataWithBaseURL(null, "<meta name='viewport' content='width=device-width,initial-scale=1'><body style='background:#171512;color:#f1eadb;font:16px sans-serif;padding:28px'><h2>Sloth todavía no está iniciado</h2><p>Inicia el servidor local de Sloth en el teléfono y vuelve a intentar.</p><button onclick='location.reload()'>Reintentar</button></body>", "text/html", "UTF-8", null);
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) { handler.cancel(); }
        });
        web.addJavascriptInterface(new AndroidFiles(), "SlothAndroid");
        setContentView(web);
        web.loadUrl("http://127.0.0.1:4848/mobile/");
    }

    private boolean isTrustedLocal(Uri uri) {
        return "http".equals(uri.getScheme()) && "127.0.0.1".equals(uri.getHost()) && uri.getPort() == 4848;
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    private void js(String expression) {
        runOnUiThread(() -> web.evaluateJavascript(expression, null));
    }

    private String quote(String value) { return JSONObject.quote(value == null ? "" : value); }

    private class AndroidFiles {
        @JavascriptInterface public void chooseFolder() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, PICK_TREE);
            });
        }

        @JavascriptInterface public String getGrantedFolder() {
            if (grantedTree == null) return "";
            return grantedTree.toString();
        }

        @JavascriptInterface public String parent(String uriText) {
            try {
                Uri current = checkedDocument(uriText);
                String rootId = DocumentsContract.getTreeDocumentId(grantedTree);
                String id = DocumentsContract.getDocumentId(current);
                if (id.equals(rootId)) return "";
                int slash = id.lastIndexOf('/');
                String parentId = slash >= 0 ? id.substring(0, slash) : rootId;
                if (parentId.length() < rootId.length() || !(parentId.equals(rootId) || parentId.startsWith(rootId + "/") || rootId.endsWith(":") && parentId.startsWith(rootId))) return "";
                return DocumentsContract.buildDocumentUriUsingTree(grantedTree, parentId).toString();
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface public String list(String uriText) {
            try {
                Uri current = checkedDocument(uriText);
                Uri tree = grantedTree;
                Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(current));
                JSONArray items = new JSONArray();
                try (Cursor c = getContentResolver().query(children, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE}, null, null, null)) {
                    if (c != null) while (c.moveToNext()) {
                        String id = c.getString(0);
                        JSONObject item = new JSONObject();
                        item.put("name", c.getString(1)); item.put("mime", c.getString(2)); item.put("size", c.isNull(3) ? 0 : c.getLong(3));
                        item.put("uri", DocumentsContract.buildDocumentUriUsingTree(tree, id).toString());
                        items.put(item);
                    }
                }
                return items.toString();
            } catch (Exception e) { return "{\"error\":" + quote(e.getMessage()) + "}"; }
        }

        @JavascriptInterface public String readText(String uriText) {
            try {
                Uri uri = checkedDocument(uriText);
                try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    if (in == null) throw new IllegalStateException("No se pudo abrir el archivo");
                    byte[] buffer = new byte[8192]; int n; int total = 0;
                    while ((n = in.read(buffer)) > 0) { total += n; if (total > 2_000_000) throw new IllegalArgumentException("Archivo demasiado grande para editar como texto (máximo 2 MB)"); out.write(buffer, 0, n); }
                    return new String(out.toByteArray(), StandardCharsets.UTF_8);
                }
            } catch (Exception e) { return "__SLOTH_ERROR__" + e.getMessage(); }
        }

        @JavascriptInterface public String readBase64(String uriText) {
            try {
                Uri uri = checkedDocument(uriText);
                try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    if (in == null) throw new IllegalStateException("No se pudo abrir el archivo");
                    byte[] buffer = new byte[16384]; int n; int total = 0;
                    while ((n = in.read(buffer)) > 0) { total += n; if (total > 20_000_000) throw new IllegalArgumentException("Archivo demasiado grande (máximo 20 MB)"); out.write(buffer, 0, n); }
                    return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                }
            } catch (Exception e) { return "__SLOTH_ERROR__" + e.getMessage(); }
        }

        @JavascriptInterface public String writeText(String uriText, String content) {
            try {
                Uri uri = checkedDocument(uriText);
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null) throw new IllegalStateException("No se pudo guardar el archivo");
                    out.write(content.getBytes(StandardCharsets.UTF_8)); out.flush();
                }
                return "ok";
            } catch (Exception e) { return "error:" + e.getMessage(); }
        }

        @JavascriptInterface public String createText(String parentUriText, String name, String content) {
            try {
                Uri parent = checkedDocument(parentUriText);
                Uri created = DocumentsContract.createDocument(getContentResolver(), parent, "text/plain", name);
                if (created == null) throw new IllegalStateException("No se pudo crear el archivo");
                try (OutputStream out = getContentResolver().openOutputStream(created, "wt")) { out.write(content.getBytes(StandardCharsets.UTF_8)); }
                return created.toString();
            } catch (Exception e) { return "__SLOTH_ERROR__" + e.getMessage(); }
        }

        @JavascriptInterface public String delete(String uriText) {
            try { return DocumentsContract.deleteDocument(getContentResolver(), checkedDocument(uriText)) ? "ok" : "error:No se pudo eliminar"; }
            catch (Exception e) { return "error:" + e.getMessage(); }
        }

        private Uri checkedTree(String text) throws Exception {
            Uri uri = Uri.parse(text);
            if (!DocumentsContract.isTreeUri(uri) || grantedTree == null || !uri.equals(grantedTree)) throw new SecurityException("Carpeta no autorizada");
            return uri;
        }
        private Uri checkedDocument(String text) throws Exception {
            Uri uri = Uri.parse(text);
            if (grantedTree == null || !grantedTree.getAuthority().equals(uri.getAuthority())) throw new SecurityException("Ubicación no autorizada");
            String rootId = DocumentsContract.getTreeDocumentId(grantedTree);
            String docId = uri.getPathSegments().contains("document") ? DocumentsContract.getDocumentId(uri) : DocumentsContract.getTreeDocumentId(uri);
            if (!(docId.equals(rootId) || docId.startsWith(rootId.endsWith(":") ? rootId : rootId + "/"))) throw new SecurityException("El archivo está fuera de la carpeta autorizada");
            return DocumentsContract.buildDocumentUriUsingTree(grantedTree, docId);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_TREE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try {
                if (grantedTree != null && !grantedTree.equals(uri)) {
                    try { getContentResolver().releasePersistableUriPermission(grantedTree, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (SecurityException ignored) {}
                }
                getContentResolver().takePersistableUriPermission(uri, flags);
                grantedTree = uri;
                getPreferences(MODE_PRIVATE).edit().putString("authorized_tree_uri", uri.toString()).apply();
            } catch (SecurityException e) { js("window.slothFolderError && window.slothFolderError(" + quote(e.getMessage()) + ")"); return; }
            js("window.slothFolderSelected && window.slothFolderSelected(" + quote(uri.toString()) + ")");
        }
    }
}
