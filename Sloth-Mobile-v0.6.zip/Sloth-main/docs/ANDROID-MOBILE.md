# Sloth Mobile (adaptación Android)

Sloth Mobile añade una interfaz móvil instalable (PWA) al servidor local de Sloth y una card `Agente general`. No sustituye el escritorio ni cambia las cards de vídeo existentes.

## Estado real

- **Implementado en este repositorio:** interfaz móvil, manifest PWA, caché de archivos estáticos, selección de modelos y esfuerzo, lista de conversaciones, historial, envío de mensajes, detener sesión, adjuntar archivos al espacio de adjuntos de Sloth y actualizaciones en vivo por WebSocket.
- **Usa el motor existente:** `POST /api/sessions`, `GET /api/sessions/:id/historial`, `POST /api/sessions/:id/send` y `POST /api/sessions/:id/stop`.
- **Aún no implementado:** APK Android nativo, puente Storage Access Framework (SAF), ejecución de Node dentro de Android, sincronización/edición directa en carpetas externas del teléfono y pruebas en dispositivo físico.

La PWA no equivale a una aplicación Android nativa y no concede por sí sola permisos de acceso a todo el almacenamiento. En el shell Android, el permiso SAF queda limitado a la carpeta que el usuario selecciona. Los archivos adjuntados al agente se copian al directorio de adjuntos administrado por Sloth; el agente trabaja sobre esa copia y no modifica automáticamente el original del teléfono. El editor SAF permite guardar manualmente cambios de texto en el archivo original.

## Probar en un equipo donde Sloth ya funcione

1. Instala las dependencias con Node 24, como exige el proyecto.
2. Ejecuta `npm start`.
3. Abre `http://localhost:4848/mobile/` desde la misma computadora.
4. Conecta Claude, Codex u OpenCode desde Sloth; la vista móvil usa los modelos que ya expone el servidor.

El servidor actual escucha solo en loopback (`127.0.0.1` y `::1`) y valida Host/Origin deliberadamente. **No lo expongas a la red local ni a Internet** para abrirlo desde otro dispositivo: no tiene autenticación de red ni TLS para ese escenario.

## Arquitectura Android pendiente

Para cumplir el requisito de almacenamiento privado + carpetas elegidas por la persona, la integración nativa deberá usar Android Storage Access Framework (`ACTION_OPEN_DOCUMENT`, `ACTION_OPEN_DOCUMENT_TREE` y permisos URI persistentes). La app debe operar solo dentro de los URI concedidos y mostrar claramente qué carpeta está autorizada.

El backend actual depende de Node 24, CLIs externos y paquetes nativos/por plataforma. Antes de empaquetarlo dentro de Android hay que auditar compatibilidad ARM64 y ejecutar los agentes desde un runtime soportado. No se debe asumir que `npm start` en Termux equivale a un backend Android estable.

## Comprobaciones

```bash
node --check web/public/mobile/app.js
node --check web/public/mobile/sw.js
npm run comprobar-mobile
```

Después, en un entorno Node 24 con dependencias instaladas, ejecutar también `npm run typecheck` y `npm test`.
