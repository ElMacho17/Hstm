# Experimento opcional: Sloth desde Android con Termux

Esto es una vía de experimentación, **no una instalación Android soportada ni un APK**. Puede fallar por la versión de Node, dependencias nativas, arquitectura ARM64, límites de procesos en segundo plano o compatibilidad de los CLIs de los agentes.

1. Instala Termux desde una fuente mantenida y actualízalo.
2. Instala herramientas básicas (`git`, `python`, `clang`, `make`, `pkg-config`) si las dependencias las requieren.
3. Usa un entorno que proporcione Node 24 ARM64. No continúes si solo tienes Node 22 u otra versión: el README del proyecto requiere Node 24.
4. Clona el repositorio, instala dependencias según el README y prueba primero el servidor en Termux.
5. Ejecuta `npm start -- --no-open` y abre `http://127.0.0.1:4848/mobile/` en el navegador del mismo teléfono.

No abras el puerto a la LAN. El backend actual está diseñado para loopback y valida el origen local; no implementa emparejamiento, autenticación remota ni TLS.

La PWA puede instalarse desde el navegador y adjuntar copias. El shell Android nativo que está en `android/` incorpora un puente SAF experimental para elegir una carpeta, explorarla y leer/guardar archivos de texto. Ese puente no está disponible en la PWA del navegador. Tampoco inicia el backend automáticamente: el servidor debe estar funcionando en `127.0.0.1:4848`.
