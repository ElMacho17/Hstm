# Crear el APK usando solo un teléfono Android

Este procedimiento usa GitHub Actions como equipo de compilación en la nube. No requiere instalar Android Studio, Termux, Java ni Gradle en el teléfono.

## Preparación única del repositorio

1. Abre tu repositorio de Sloth en GitHub desde el navegador del teléfono.
2. Añade el archivo `.github/workflows/android-apk.yml` de esta versión, respetando exactamente esa ruta. Si GitHub no te deja subir carpetas, crea primero `.github`, dentro `workflows` y luego el archivo `android-apk.yml` copiando su contenido desde el ZIP.
3. Sube el archivo `Sloth-Mobile-v0.6.zip` a la raíz del repositorio. No hace falta extraerlo en el teléfono: el propio flujo lo descomprime en el equipo de compilación de GitHub.
4. Espera a que se ejecute la acción automáticamente o abre **Actions** → **Crear APK de Sloth Mobile** → **Run workflow**.

## Descargar el APK

1. En el repositorio, abre **Actions**.
2. Abre la ejecución más reciente de **Crear APK de Sloth Mobile**.
3. Espera a que termine en verde.
4. Baja hasta **Artifacts** y descarga `sloth-mobile-debug-apk`.
5. Extrae `app-debug.apk` del ZIP descargado.
6. Abre el APK desde Descargas. Android te pedirá autorizar la instalación desde esa fuente si aún no lo has permitido.

## Qué genera esta compilación

Genera un APK de depuración del contenedor Android (versión 0.5.0). Es una compilación de prueba, no una versión firmada para publicar en Play Store.

**Limitación funcional actual:** el contenedor intenta abrir el backend local en `http://127.0.0.1:4848/mobile/`. Este workflow solo compila el contenedor; no incorpora ni inicia Node.js ni los motores Claude/Codex/OpenCode dentro de Android. Por eso, instalar este APK todavía no equivale a tener el agente completo funcionando. La pantalla indicará que Sloth aún no está iniciado si el backend no está disponible.

No compartas tokens, claves API ni secretos dentro del repositorio. La compilación no necesita credenciales de proveedores para generar el APK de prueba.
