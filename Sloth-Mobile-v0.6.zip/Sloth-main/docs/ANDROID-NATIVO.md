# Sloth Mobile: shell Android y acceso SAF

Esta carpeta contiene el primer shell nativo Android (Java + WebView) y un puente limitado de Storage Access Framework.

## Qué está implementado en el código

- Aplicación Android con `MainActivity` y WebView.
- La WebView solo navega/carga recursos HTTP desde `127.0.0.1`; enlaces externos se abren fuera de la app y las solicitudes de otros hosts se bloquean.
- JavaScript bridge `SlothAndroid` para elegir una carpeta con `ACTION_OPEN_DOCUMENT_TREE` y conservar el permiso URI persistente.
- Exploración de la carpeta autorizada y sus subcarpetas.
- Lectura y guardado de archivos de texto; creación de archivos `.txt` y eliminación mediante SAF.
- La interfaz móvil puede abrir el panel **Carpetas**, editar archivos de texto directamente y adjuntar una copia de un archivo al agente. La copia adjunta se carga al backend Sloth; el original no se modifica por adjuntarlo.
- No solicita `MANAGE_EXTERNAL_STORAGE` ni permisos generales de almacenamiento.

## Limitación importante del backend

Este shell **no arranca Node.js ni los agentes por sí solo**. Espera que el backend Sloth esté ejecutándose en el mismo teléfono y escuchando en `127.0.0.1:4848`. El backend original requiere Node 24 y depende de CLIs y paquetes cuya compatibilidad Android/ARM64 todavía debe validarse. Por tanto, el proyecto Android es un scaffold de integración y no debe confundirse con un APK funcional ya probado.

## Compilación

Requisitos previstos: JDK 17+, Android SDK Platform 35, Android Build Tools compatibles y Gradle 8.9 o superior con Android Gradle Plugin 8.7.3.

```bash
cd android
gradle assembleDebug
```

Este repositorio todavía no incluye `gradlew` ni el wrapper JAR. Genera el wrapper en un equipo con Gradle instalado (`gradle wrapper --gradle-version 8.9`) antes de usar `./gradlew`. Después instala `app/build/outputs/apk/debug/app-debug.apk` y prueba con el backend local activo.

## SAF y límites

El permiso persistente se concede únicamente para la carpeta elegida por la persona. El puente valida que los URI usados pertenezcan a esa carpeta. El editor directo está pensado para texto; no es un visor/editor binario. La lectura desde SAF está limitada a 2 MB por archivo en este prototipo.

Antes de distribuir: añadir pruebas instrumentadas, manejar proveedores SAF no estándar, robustecer errores/permisos revocados, probar Android 10–15 y revisar la ejecución del backend/agentes en ARM64. No exponer el servidor a LAN/Internet: el servidor de escritorio está diseñado para loopback y no tiene autenticación remota.
